<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate the Product</title>

    <link rel="stylesheet" href="<?php echo base_url('public/CSS/bootstrap.css');?>" />


    <script src="<?php echo base_url('public/SCRIPTS/jquery.js');?>"></script>
    <script src="<?php echo base_url('public/SCRIPTS/bootstrap.js');?>"></script>

    <style>
    .card:hover{
   box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
}
.card-header{
    text-align: center;
    background: #f688bb;
    color: white;
}
.control-label{
    color: #5b8c5a;
}
    </style>

</head>
<body>
<div class="container" style="padding: 50px;">
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">Register</div>
            <div class="card-body">
                 <form method="post" action="<?php echo base_url('home/register');?>">
                     <?php

                        if(!empty(validation_errors())){
                            print("
                            <div class='alert alert-danger alert-dismissible fade show' role='alert'>
                                <strong>Error!</strong>".validation_errors()."
                                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                </button>
                            </div>"
                        );
                            
                        }
                    ?>
                    

                    <div class="form-group">
                        <label class="cols-sm-2 control-label"> Your Name   </label>
                        <div class="cols-sm-10">
                            <div class="input-group">
                                <input type="text" class="form-control" name="name" id="name" placeholder="Enter your name">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="cols-sm-2 control-label"> Your Email  </label>
                        <div class="cols-sm-10">
                            <div class="input-group">
                                <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="cols-sm-2 control-label"> Your Password   </label>
                        <div class="cols-sm-10">
                            <div class="input-group">
                                <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password">
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <button type="submit" class="btn btn-success btn-lg btn-block login-button">Register</button>
                    </div>
                    <div class="login-register">
                        Already a member? <a href="<?php echo base_url('login'); ?>">Login</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>  
</div>
       
        
           

           
    
</body>
</html>

