<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate the Product</title>
    
    <link rel="stylesheet" href="<?php echo base_url('public/CSS/bootstrap.css');?>" />
    <link rel="stylesheet" href="<?php echo base_url('public/CSS/style.css');?>" />


    <script src="<?php echo base_url('public/SCRIPTS/jquery.js');?>"></script>
    <script src="<?php echo base_url('public/SCRIPTS/bootstrap.js');?>"></script>

</head>
    <body>
        <div class="navbar">
            <div class="logo">
            <a href="#home" style="text-decoration: none;">
                <img src="<?php echo base_url('public/images/logo3.svg');?>" alt="hero image" height="50px" width="50px" style="margin-left: 30px">
                <div style="margin-top: 1px; color: #0BADBF; font-weight: 700;">ITrendy Fashions</div>
            </a>
            </div>
            <a class="btn">
            <span></span>
            <span></span>
            <span></span>
            </a>
            <div class="menu">
              <a href="#">Home</a>
              <a href="#">About</a>
              <a href="#">Cart</a>
              <a href="#">Contact</a>
              <a href="#">My Account</a>
              <a href="<?php echo base_url('login/logout'); ?>">Logout</a>

            </div>
            </div>

<div class="container1"> 
    <div class="hero-text">
        <h1 >ITrendy  Fashions</h1>
        <h3>All fashions you need</h3>
        <button class="but">Shop Now</button>
    </div>   
</div>
      
      <div class="cardss">
        <div class="super_container">
            <div class="single_product">
                <div class="container-fluid" style=" background-color: #fff; padding: 11px;">
                    <div class="row">
                        <div class="col-lg-4 order-lg-2 order-1">
                            <div class="image_selected"><img src="<?php echo $product->product_Image; ?>" alt=""></div>
                        </div>
                        <div class="col-lg-6 order-3">
                            <div class="product_description">
                                <div class="product_name"><?php echo $product->product_name; ?></div>
                                <div class="product-rating"><span class="badge badge-success"> <?php echo round($rating->rate,1); ?> Star</span> <span class="rating-review"><?php echo $rating->num; ?> Ratings</span></div>
                                <div> <span class="product_price">₹ <?php echo $product->price; ?></span></div>
                                
                                <hr class="singleline">
                                <div>
                                    <?php
                                        echo $product->description;
                                    ?>
                                </div>
                            </div>

                            <?php
                                if($check == 0 ):
                            ?>
                                <hr class="singleline">
                                <div class="user-rating">
                                    <h4>Rate this Product:</h4>
                                    <form method="get" action="<?php echo base_url('Product/rate');?>">
                                        <div class="row">
    <div class="rating">
      
      <input type="radio" id="star5" name="rating" value="5" /><label for="star5" title="Excellent">5 stars</label>
      <input type="radio" id="star4" name="rating" value="4" /><label for="star4" title="Very Good">4 stars</label>
      <input type="radio" id="star3" name="rating" value="3" /><label for="star3" title="Good">3 stars</label>
      <input type="radio" id="star2" name="rating" value="2" /><label for="star2" title="Bad">2 stars</label>
      <input type="radio" id="star1" name="rating" value="1" /><label for="star1" title="Very Bad">1 star</label>
    </div>
    </div>
                                        <input type="hidden" name="id" value="<?php echo $id; ?>" />
                                        <button class="btn btn-outline-success my-3" style="display: block;left: 20px;" type="submit">
                                            Submit
                                        </button>
                                    </form>
                                </div>
                                <?php endif; ?>

                                <div>
                                    <a class="btn btn-outline-danger my-3"  href="<?php echo base_url('products');?>" style="display: block">Go back</a>
                                </div>
                                <br><br><br><br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </body>
</html>