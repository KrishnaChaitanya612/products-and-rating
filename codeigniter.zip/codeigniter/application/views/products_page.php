<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate the Product</title>

    <link rel="stylesheet" href="<?php echo base_url('public/CSS/bootstrap.css');?>" />
    <link rel="stylesheet" href="<?php echo base_url('public/CSS/style.css');?>" />


    <script src="<?php echo base_url('public/SCRIPTS/jquery.js');?>"></script>
    <script src="<?php echo base_url('public/SCRIPTS/bootstrap.js');?>"></script>

  

</head>
<body>
        
        <div class="navbar">
            <div class="logo">
            <a href="#home" style="text-decoration: none;">
                <img src="<?php echo base_url('public/images/logo3.svg');?>" alt="hero image" height="50px" width="50px" style="margin-left: 30px">
                <div style="margin-top: 1px; color: #0BADBF; font-weight: 700;">ITrendy Fashions</div>
            </a>
            </div>
            <a class="btn">
            <span></span>
            <span></span>
            <span></span>
            </a>
            <div class="menu">
              <a href="#">Home</a>
              <a href="#">About</a>
              <a href="#">Cart</a>
              <a href="#">Contact</a>
              <a href="#">My Account</a>
              <a href="<?php echo base_url('login/logout'); ?>">Logout</a>

            </div>
            </div>

<div class="container1">
 
    <div class="hero-text">
        <h1 >ITrendy  Fashions</h1>
        <h3>All fashions you need</h3>
        <button class="but">Shop Now</button>
    </div>
 
    
</div>  
<div class="main">
  <h1 style="text-align: center;color: #068896">Shop by category</h1>
  <ul class="cards">
     <?php
                foreach($products as $product):
    ?>
    <li class="cards_item">
      <div class="cardss">
        <div class="card_image"><img src="<?php echo $product->product_Image; ?>" alt="<?php echo $product->product_name; ?>"></div>
        <div class="card_content">
          <h2 class="card_title"> <?php echo $product->product_name; ?></h2><br>
          <p class="card_text"> <?php echo $product->description; ?> </p>
          <h2 class="card_title">Cost :$ <?php echo $product->price; ?></h2>
          <center><a href="<?php echo base_url('product?id='.$product->id); ?>"><button class="card_but">Know More</button></a></center>

        </div>
      </div>
    </li>
        <?php
                endforeach;
            ?>
    </ul>
    </div>      

   

<script type="text/javascript">

$(".btn").on("click",function(){
  $('.menu').toggleClass("show");
});


</script>


</body>
</html>